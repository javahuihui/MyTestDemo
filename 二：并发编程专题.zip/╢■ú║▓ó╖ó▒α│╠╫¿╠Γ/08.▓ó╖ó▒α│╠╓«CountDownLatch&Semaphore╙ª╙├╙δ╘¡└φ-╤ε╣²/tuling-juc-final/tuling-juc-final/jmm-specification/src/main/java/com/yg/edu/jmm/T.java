package com.yg.edu.jmm;

/**
 *
 * @author ：杨过
 * @date ：Created in 2020/8/5
 * @version: V1.0
 * @slogan: 天下风云出我辈，一入代码岁月催
 * @description:
 **/
public class T {

    public void methdo(){
        new Object();
    }
}
