# 异步请求的封装uni.request



## 01、理解

uniapp是对vue封装，内置nodejs，webpack ,vue-cli项目中常见的一些组件都已经进行内置在hbuilderx。你只需要使用hbx这个工作就可以完成的app开发和打包部署的工作。

但是在前面vue的课程和vue-cli脚手架，异步请求是使用：axios来完成和处理。但是在小程序和uniapp里面就不是使用axios来处理。小程序也好还是uniapp它们都各自封装了对应异步请求的api比如：

uniapp

```json
uni.request({
    url: 'https://www.example.com/request', //仅为示例，并非真实接口地址。
    data: {
        text: 'uni.request'
    },
    header: {
        'custom-header': 'hello' //自定义请求头信息
    },
    success: (res) => {
        console.log(res.data);
        this.text = 'request success';
    }
});
```

微信小程序

```json
wx.request({
  url: 'example.php', //仅为示例，并非真实的接口地址
  data: {
    x: '',
    y: ''
  },
  header: {
    'content-type': 'application/json' // 默认值
  },
  success (res) {
    console.log(res.data)
  }
})
```



## 02、对uni.request封装

- 第一个：为了方便进行调用
- 第二个：为方便统一进行处理和控制，请求和相应。我们可以在请求的过程中对齐讲参数进行设置，比如token放入请求头中，以及对响应的统一拦截处理比如：服务500错误可以在封装进行提示，也可以请求错误给一个统一的处理等。

封装的原理：Promise 

组件：uview组件已经使用promise对uni.request进行，参照了axios的原理进行封装，其中就包含类似于axios的统一配置，请求拦截，响应拦截处理。

## 03、认识uview的异步请求

该插件适用于普遍的请求场景，支持`post`、`get`、`put`和`delete`，以及上传下载等请求，有如下特点：

- 基于`Promise`对象实现更简单的`request`使用方式，支持请求和响应拦截
- 支持全局挂载
- 支持多个全局配置实例
- 支持自定义验证器
- 支持文件上传/下载
- 支持task 操作
- 支持自定义参数
- 支持多拦截器
- 对参数的处理比`uni.request`更强

### 基本使用

```js
uni.$u.http.middleware(config)
uni.$u.http.request(config)
uni.$u.http.get(url[, config])
uni.$u.http.upload(url[, config])
uni.$u.http.delete(url[, data[, config]])
uni.$u.http.head(url[, data[, config]])
uni.$u.http.post(url[, data[, config]])
uni.$u.http.put(url[, data[, config]])
uni.$u.http.connect(url[, data[, config]])
uni.$u.http.options(url[, data[, config]])
uni.$u.http.trace(url[, data[, config]])
```

uview它不是官方的组件，也官方提供。它纯属属于个个人爱好基于uniapp开发的一套组件和异步请求和工具集组局和工具库。在你安装和到



## 定义封装request.js

在config/request.js如下：

```js
import server from './server.js'
import cache from './cache.js'

var request = function(app){ 
	// 初始化请求配置
    uni.$u.http.setConfig((config) => {
		config.baseURL = server.baseURL+"/api";
        return config
    })
	
	// 请求拦截 
	uni.$u.http.interceptors.request.use((config) => { 
	    // 初始化请求拦截器时，会执行此方法，此时data为undefined，赋予默认{}
	    config.data = config.data || {auth:true}
		// 根据custom参数中配置的是否需要token，添加对应的请求头
		var isAuth = config.data.auth;
		if(isAuth) {
			const token = cache.get("token");//从缓存中获取
			console.log("token--------------",token);
			if(token){
				// 可以在此通过vm引用vuex中的变量，具体值在vm.$store.state中
				config.header.token = token;
			}else{
				uni.redirectTo({
					url:"/pages/login/login"
				})
				//config.custom.auth = false;
				//return Promise.reject("login");//直接走catch
			}
		}
	    return config 
	}, config => { // 可使用async await 做异步操作
	    return Promise.reject(config)
	})
	
	// 响应拦截
	uni.$u.http.interceptors.response.use((response) => { 
		const data = response.data
		// 不等于200说明都是错误返回，进行弹出提示
		if (data.code !== 200) { 
			uni.$u.toast(data.message);
			return Promise.reject(data);//直接走catch
		}
		
		return data === undefined ? {} : data
	}, (response) => { 
		if(response != 'login'){
			uni.$u.toast("服务器离开地球表面...");
		}
		return Promise.reject(response)
	})
}

// 此vm参数为页面的实例，可以通过它引用vuex中的变量
// export default ===== import from
// module exports ===== required
module.exports = request;
```

在main.js中进行注册

```js
require('@/config/request.js')(app);
```

### 集中管理处理

在config/api.js如下：开始定义接口和处理逻辑，如果你app的业务和接口比较单一可以考虑使用下面定义：

```js
// 导入异步请求
const http = uni.$u.http

// post请求，获取菜单
export const postMenu = (params, config = {}) => http.post('/ebapi/public_api/index', params, config)

// get请求，获取菜单，注意：get请求的配置等，都在第二个参数中，详见前面解释
export const getMenu = (data) => http.get('/ebapi/public_api/index', data)

// post请求，获取菜单
export const login = (params, config = {}) => http.post('/ebapi/public_api/index', params, config)

// post请求，获取菜单
export const searchHotelList = (params, config = {}) => http.post('/ebapi/public_api/index', params, config)

// post请求，获取菜单
export const getHotelDetail = (params, config = {}) => http.post('/ebapi/public_api/index', params, config)

// post请求，获取菜单
export const getHotelCategories = (params, config = {}) => http.post('/ebapi/public_api/index', params, config)

```

### 模块化处理1：

```js

const http = uni.$u.http
export default {
	login:{
		toLogin(params,config){
			return http.post('/ebapi/public_api/index', params, config);
		}
	},
	
	hotel:{
		selectList(){
			return http.post('/ebapi/public_api/index', params, config);
		}
	},
	
	order:{
		selectOrder(){
			return http.post('/ebapi/public_api/index', params, config);
		}
	}
}
```



### 模块处理2：

![image-20220317212433054](asserts/image-20220317212433054.png)





## 4. 发送请求

```js

import {} from '@/service/login/LoginService'

// 发出post，假设需要带上token
var promise = toLogin({ custom: { auth: true }});
promise.then(() => {
	
}).catch(() =>{
	
})

```



## 05、uni和$u的绑定关系

```js
// 看到此报错，是因为没有配置vue.config.js的【transpileDependencies】，详见：https://www.uviewui.com/components/npmSetting.html#_5-cli模式额外配置
const pleaseSetTranspileDependencies = {}, babelTest = pleaseSetTranspileDependencies?.test



// 引入全局mixin
import mixin from './libs/mixin/mixin.js'
// 小程序特有的mixin
import mpMixin from './libs/mixin/mpMixin.js'
// 全局挂载引入http相关请求拦截插件
import Request from './libs/luch-request'

// 路由封装
import route from './libs/util/route.js'
// 颜色渐变相关,colorGradient-颜色渐变,hexToRgb-十六进制颜色转rgb颜色,rgbToHex-rgb转十六进制
import colorGradient from './libs/function/colorGradient.js'

// 规则检验
import test from './libs/function/test.js'
// 防抖方法
import debounce from './libs/function/debounce.js'
// 节流方法
import throttle from './libs/function/throttle.js'
// 公共文件写入的方法
import index from './libs/function/index.js'

// 配置信息
import config from './libs/config/config.js'
// props配置信息
import props from './libs/config/props.js'
// 各个需要fixed的地方的z-index配置文件
import zIndex from './libs/config/zIndex.js'
// 关于颜色的配置，特殊场景使用
import color from './libs/config/color.js'
// 平台
import platform from './libs/function/platform'

const $u = {
    route,
    date: index.timeFormat, // 另名date
    colorGradient: colorGradient.colorGradient,
    hexToRgb: colorGradient.hexToRgb,
    rgbToHex: colorGradient.rgbToHex,
    colorToRgba: colorGradient.colorToRgba,
    test,
    type: ['primary', 'success', 'error', 'warning', 'info'],
    http: new Request(),
    config, // uView配置信息相关，比如版本号
    zIndex,
    debounce,
    throttle,
    mixin,
    mpMixin,
    props,
    ...index,
    color,
    platform
}

// $u挂载到uni对象上
uni.$u = $u

```





