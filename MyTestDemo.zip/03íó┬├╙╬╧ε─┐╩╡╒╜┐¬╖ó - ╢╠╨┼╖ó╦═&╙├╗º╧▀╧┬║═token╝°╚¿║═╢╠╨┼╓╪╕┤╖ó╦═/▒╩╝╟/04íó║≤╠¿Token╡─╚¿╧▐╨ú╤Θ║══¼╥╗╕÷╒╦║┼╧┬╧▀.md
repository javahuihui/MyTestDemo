# 后台Token的权限校验和同一个账号下线



## 01、为什么要token

- 保证接口的安全性



## 02、鉴权拦截的思考？

- AOP

  - 拦截方法
  - 使用注解

- 拦截器

  - /api/**

    

## 03、实现流程

![image-20220318005026198](asserts/image-20220318005026198.png)

![image-20220318005405493](asserts/image-20220318005405493.png)



1：登录改造

```java
package com.pug.web.login;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.pug.bo.KssUserBo;
import com.pug.pojo.KssUser;
import com.pug.result.ex.KsdBusinessException;
import com.pug.service.idwork.IdWorkService;
import com.pug.service.user.IUserService;
import com.pug.utils.FastJsonUtil;
import com.pug.utils.fn.asserts.Vsserts;
import com.pug.vo.KssUserVo;
import com.pug.web.BaseController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.UUID;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/16$ 23:56$
 */
@Api(tags = "登录管理")
@RestController
@RequiredArgsConstructor
public class PassportLoginController extends BaseController {

    private final IUserService userService;
    private final IdWorkService idWorkService;

    @ApiOperation("登录方法")
    @PostMapping("/passport/login")
    public KssUserBo toLoginReg(@RequestBody @Valid KssUserVo kssUser) {
        // 1: 接受用户提交用户手机和短信
        String inputPhone = kssUser.getPhone();
        String inputSmsCode = kssUser.getSmscode();
        // 2: 获取redis缓存中的存储短信
        String cacheSmsCode = redisOperator.get(PUG_XQ_LOGIN_SMS_CODE + inputPhone);
        Vsserts.isEmptyEx(cacheSmsCode, "短信已经失效");
        // 3: 对比短信码是否正确
        if (!cacheSmsCode.equalsIgnoreCase(inputSmsCode)) {
            throw new KsdBusinessException(602, "你输入短信证码有误!");
        }
        // 4：开始进行业务的处理
        KssUser dbUser = userService.getByPhone(inputPhone);
        // 如果dbUser，说明没有注册
        if (Vsserts.isNull(dbUser)) {
            // 开始注册
            dbUser = new KssUser();
            dbUser.setPhone(inputPhone);
            dbUser.setIdcode(idWorkService.nextShort());
            dbUser.setNickname("小伴");
            dbUser.setPassword("");
            dbUser.setAvatar("aa.jpg");
            dbUser.setSex(2);
            dbUser.setCountry("中国");
            dbUser.setProvince("");
            dbUser.setCity("");
            dbUser.setDistrict("");
            dbUser.setDescription("Ta什么都没有留下...");
            dbUser.setBgImg("biimg.jpg");
            dbUser.setStatus(1);
            userService.saveOrUpdate(dbUser);
        }

        // 5: 存在就返回
        KssUserBo kssUserBo = new KssUserBo();
        BeanUtils.copyProperties(dbUser, kssUserBo);
        // 6: 生成一个uuid代表token
        String tokenUuid = UUID.randomUUID().toString();
        kssUserBo.setToken(tokenUuid);
        // 7 : 登录成功以后
        redisOperator.set(PUG_XQ_LOGIN_USER_INFO+kssUserBo.getId(), FastJsonUtil.toJSON(kssUserBo));
        redisOperator.set(PUG_XQ_LOGIN_USER_TOKEN+kssUserBo.getId(),tokenUuid);
        // 8：而且短信码一定注册成功其实也没有任何用处，会占用redis内存空间，所有删除掉
        redisOperator.del(PUG_XQ_LOGIN_SMS_CODE + inputPhone);

        return kssUserBo;
    }

}

```



2:定义鉴权拦截器

```java
package com.pug.config.interceptor;

import com.pug.constant.PugContants;
import com.pug.pojo.KssUser;
import com.pug.result.ResultEnum;
import com.pug.result.ex.KsdValidationException;
import com.pug.service.redis.PugRedisOperator;
import com.pug.threadlocal.UserThrealLocal;
import com.pug.utils.FastJsonUtil;
import com.pug.utils.fn.asserts.Vsserts;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/6$ 2:51$
 */
@Component
@Slf4j
public class PassportTokenInterceptor implements HandlerInterceptor, PugContants {

    @Autowired
    private PugRedisOperator redisOperator;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 1: 获取前台接口调用请求头中的用户和token参数
        String authUserId = request.getHeader("AuthUserId");
        String authToken = request.getHeader("AuthToken");
        // 2: 如果token和userId是空的，就直接返回
        if (Vsserts.isNotEmpty(authUserId) && Vsserts.isNotEmpty(authToken)) {
            // 根据用户id查询缓存中的token
            String redisToken = redisOperator.get(PUG_XQ_LOGIN_USER_TOKEN  + authUserId);
            // 如果是空，就说明退出了。
            if (Vsserts.isEmpty(redisToken)) {
                //直接在前台响应地方跳转到登录去
                throw new KsdValidationException(ResultEnum.LOGIN_FAIL);
            }
            // 如果不是空，说明用户前台app或者小程序传递了token，
            // 把传递进来的token和缓存中的token进行比较看是否一致
            // google浏览器：说明它肯定退出一次然后又登录了 user:1 token 545454545
            // firefox浏览器：说明它肯定退出一次然后又登录了 user:1 token 878787878
            if (!redisToken.equalsIgnoreCase(authToken)) {
                throw new KsdValidationException(ResultEnum.SAME_LOGIN);
            }
        } else {
            throw new KsdValidationException(ResultEnum.LOGIN_FAIL);
        }

        // 从缓存中获取用户信息
        String userCacheJson = redisOperator.get(PUG_XQ_LOGIN_USER_INFO  + authUserId);
        KssUser kssUser = FastJsonUtil.toBean(userCacheJson, KssUser.class);
        UserThrealLocal.put(kssUser);
        
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        UserThrealLocal.remove();
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        UserThrealLocal.remove();
    }
}


```

3：注册拦截器

```java
@Autowired
public PassportTokenInterceptor passportTokenInterceptor;

/**
     * 注册拦截器
     *
     * @param registry
     */
@Override
public void addInterceptors(InterceptorRegistry registry) {
    // 验证码拦截
    registry.addInterceptor(passportInterceptor).addPathPatterns("/passport/smssend/**");        //registry.addInterceptor(refererInterceptor).addPathPatterns("/api/**");
    // token 拦截
    registry.addInterceptor(passportTokenInterceptor).addPathPatterns("/api/**");

}
```

