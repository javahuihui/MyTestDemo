# 02、异步请求的封装uni.setStorage

## 1：概述

将数据存储在本地缓存中指定的 key 中，会覆盖掉原来该 key 对应的内容，这是一个异步接口。封装的是:locaclStorage

## 2：config/cache.js定义缓存，如下

```js

export default {

	// 放入缓存中
	set(key, value) {
		var key = 'pug_app_' + key;
		try {
			// 全局里放
			getApp().globalData[key] = value;
			// 缓存里也放入
			uni.setStorageSync(key, value)
		} catch (e) {
			console.log("cache error");
		}
	},

	// 从缓存中获取
	get(key) {
		var key = 'pug_app_' + key;
		try {
			// 全局里放
			return uni.getStorageSync(key) || getApp().globalData[key]
		} catch (e) {
			return null;
		}
	},

	// 根据key删除缓存
	remove(key) {
		var key = 'pug_app_' + key;
		try {
			uni.removeStorageSync(key);
			getApp().globalData[key] = null;
		} catch (e) {}
	}


}

```



## **注意**

uni-app的Storage在不同端的实现不同：

- H5端为localStorage，浏览器限制5M大小，是缓存概念，可能会被清理
- App端为原生的plus.storage，无大小限制，不是缓存，是持久化的
- 各个小程序端为其自带的storage api，数据存储生命周期跟小程序本身一致，即除用户主动删除或超过一定时间被自动清理，否则数据都一直可用。
- 微信小程序单个 key 允许存储的最大数据长度为 1MB，所有数据存储上限为 10MB。
- 支付宝小程序单条数据转换成字符串后，字符串长度最大200*1024。同一个支付宝用户，同一个小程序缓存总上限为10MB。
- 百度、字节跳动小程序文档未说明大小限制
- 非App平台清空Storage会导致uni.getSystemInfo获取到的deviceId改变

