# Hbuilderx如何管理各种小程序的开发工具

1: 下载微信小程序

下载地址：https://developers.weixin.qq.com/miniprogram/dev/devtools/download.html

![image-20220316014101108](asserts/image-20220316014101108.png)

2：无脑安装，

3：把微信小程序的安装找到

![image-20220316014216830](asserts/image-20220316014216830.png)

4：使用hbuilderx关联即可。

![image-20220316014315423](asserts/image-20220316014315423.png)

![image-20220316014401655](asserts/image-20220316014401655.png)

然后保存

5：然后就可以运行了

![image-20220316014504897](asserts/image-20220316014504897.png)

