# ThreadLocal获取用户信息



## 说明

在程序开发中，我们经常有一些业务要和用户打交道。难免要获取用户信息，才能进行操作。比如：

- 下单
- 评论
- 购物车
- ……..

大部分的人做法：直接从前台和其他的参数一起传递过来。这个种是没有问题，但是会造成参数过多，用户信息外露。



## 获取用户信息

- 放session(单体架构工程) 
- 前后端分类，为什么不能用session了？
  - session是通过cookie来维护各个请求的数据共享问题。底层一个map。我们登录以后把用户如果放到session其实服务器端会产生一个sessionid，和一个jsessionid然后使用cookie进行response输出。后续所有的请求只要携带这个jessionid就可以在服务器端比对，如果存在说明信息可以获取到。
  - cookie是通过：域 locahost 和path / 隔离和区分一种本地缓存机制。而APP和小程序它们内部是屏蔽cookie的概念，所以你无法进行数据获取交互。
  - 传递用户参数
- 本地存储用户信息获取
  - redis
  - ThreadLocal
  - springmvc参数注入



## 为什么不用UUID作为token，而用JWT生成Token

- uuid没有特征，不具备过期失效的功能，没有携带有效信息
- jwt生成的token，具备过期失效的特征，携带有效信息





## SpringBoot对接本地缓存Ehcache

1：依赖

```xml
<dependency>
    <groupId>net.sf.ehcache</groupId>
    <artifactId>ehcache</artifactId>
    <version>2.10.1</version>
</dependency>
```

2：开启二级缓存 @EnableCaching

```java
package com.pug;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/16$ 23:47$
 */
@SpringBootApplication
@MapperScan("com.pug.mapper")
@EnableCaching
@EnableMongoRepositories
public class TravelsWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(TravelsWebApplication.class);
    }

}

```

3：在resource目录下在新建echcache.xml文件如下

```xml
<?xml version="1.0" encoding="UTF-8"?>
<ehcache xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:noNamespaceSchemaLocation="ehcache.xsd">
    <!--timeToIdleSeconds 当缓存闲置n秒后销毁 -->
    <!--timeToLiveSeconds 当缓存存活n秒后销毁 -->
    <!-- 缓存配置
        name:缓存名称。
        maxElementsInMemory：缓存最大个数。
        eternal:对象是否永久有效，一但设置了，timeout将不起作用。
        timeToIdleSeconds：设置对象在失效前的允许闲置时间（单位：秒）。仅当eternal=false对象不是永久有效时使用，可选属性，默认值是0，也就是可闲置时间无穷大。
        timeToLiveSeconds：设置对象在失效前允许存活时间（单位：秒）。最大时间介于创建时间和失效时间之间。仅当eternal=false对象不是永久有效时使用，默认是0.，也就是对象存活时间无穷大。
        overflowToDisk：当内存中对象数量达到maxElementsInMemory时，Ehcache将会对象写到磁盘中。 diskSpoolBufferSizeMB：这个参数设置DiskStore（磁盘缓存）的缓存区大小。默认是30MB。每个Cache都应该有自己的一个缓冲区。
        maxElementsOnDisk：硬盘最大缓存个数。
        diskPersistent：是否缓存虚拟机重启期数据 Whether the disk
        store persists between restarts of the Virtual Machine. The default value
        is false.
        diskExpiryThreadIntervalSeconds：磁盘失效线程运行时间间隔，默认是120秒。  memoryStoreEvictionPolicy：当达到maxElementsInMemory限制时，Ehcache将会根据指定的策略去清理内存。默认策略是
LRU（最近最少使用）。你可以设置为FIFO（先进先出）或是LFU（较少使用）。
        clearOnFlush：内存数量最大时是否清除。 -->
    <!-- 磁盘缓存位置 -->
    <diskStore path="java.io.tmpdir" />
    <!-- 默认缓存 -->
    <defaultCache
            maxElementsInMemory="10000"
            eternal="false"
            timeToIdleSeconds="120"
            timeToLiveSeconds="120"
            maxElementsOnDisk="10000000"
            diskExpiryThreadIntervalSeconds="120"
            memoryStoreEvictionPolicy="LRU">
        <persistence strategy="localTempSwap" />
    </defaultCache>

    <cache name="objectCache"
           maxElementsInMemory="10000"
           eternal="false"
           timeToIdleSeconds="120"
           timeToLiveSeconds="120"
           maxElementsOnDisk="10000000"
           diskExpiryThreadIntervalSeconds="120"
           memoryStoreEvictionPolicy="LRU">
        <persistence strategy="localTempSwap"/>
    </cache>


</ehcache>


```

不懂查看这篇文章：https://blog.csdn.net/qq_28988969/article/details/78210873

EhCache
JAVA缓存实现方案有很多，最基本的自己使用Map去构建缓存，或者使用memcached或Redis，但是上述两种缓存框架都要搭建服务器，而Map自行构建的缓存可能没有很高的使用效率，那么我们可以尝试一下使用Ehcache缓存框架。

Ehcache主要基于内存缓存，磁盘缓存为辅的，使用起来方便。

ehcache.xml配置文件详解

<ul><li>diskStore：为缓存路径，ehcache分为内存和磁盘两级，此属性定义磁盘的缓存位置。</li><li>defaultCache：默认缓存策略，当ehcache找不到定义的缓存时，则使用这个缓存策略。只能定义一个。</li><li>name:缓存名称。</li><li>maxElementsInMemory:缓存最大数目</li><li>maxElementsOnDisk：硬盘最大缓存个数。</li><li>eternal:对象是否永久有效，一但设置了，timeout将不起作用。</li><li>overflowToDisk:是否保存到磁盘，当系统宕机时</li><li>timeToIdleSeconds:设置对象在失效前的允许闲置时间（单位：秒）。仅当eternal=false对象不是永久有效时使用，可选属性，默认值是0，也就是可闲置时间无穷大。</li><li>timeToLiveSeconds:设置对象在失效前允许存活时间（单位：秒）。最大时间介于创建时间和失效时间之间。仅当eternal=false对象不是永久有效时使用，默认是0.，也就是对象存活时间无穷大。</li><li>diskPersistent：是否缓存虚拟机重启期数据 Whether the disk store persists between restarts of the Virtual Machine. The default value is false.</li><li>diskSpoolBufferSizeMB：这个参数设置DiskStore（磁盘缓存）的缓存区大小。默认是30MB。每个Cache都应该有自己的一个缓冲区。</li><li>diskExpiryThreadIntervalSeconds：磁盘失效线程运行时间间隔，默认是120秒。</li><li>memoryStoreEvictionPolicy：当达到maxElementsInMemory限制时，Ehcache将会根据指定的策略去清理内存。默认策略是LRU（最近最少使用）。你可以设置为FIFO（先进先出）或是LFU（较少使用）。</li><li>clearOnFlush：内存数量最大时是否清除。</li></ul>

4：配置

```yml
spring:
  cache:
    ehcache:
      config: classpath:ehcache.xml
```

5:定义缓存的处理Service

```java
package com.pug.config.cache;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class EHCacheService {

    @Autowired
    private CacheManager cacheManager;

    /**
     * 设置缓存对象
     *
     * @param key
     * @param object
     */
    public void setCache(String key, Object object) {
        Cache cache = cacheManager.getCache("objectCache");
        Element element = new Element(key, object);
        cache.put(element);
    }

    /**
     * 从缓存中取出对象
     *
     * @param key
     * @return
     */
    public Object getCache(String key) {
        Object object = null;
        Cache cache = cacheManager.getCache("objectCache");
        if (cache.get(key) != null && !cache.get(key).equals("")) {
            object = cache.get(key).getObjectValue();
        }
        return object;
    }

    public boolean removeCache(String key) {
        Object object = null;
        Cache cache = cacheManager.getCache("objectCache");
        if (cache.get(key) != null && !cache.get(key).equals("")) {
            return cache.remove(key);
        }
        return false;
    }
}
```





## ThreadLocal的妙用

本地线程 - 线程副本

```java
package com.pug.config.threadlocal;


import com.pug.pojo.KssUser;

/**
 * @author 飞哥yykk
 * 更多学习关注飞哥B站
 * 地址是：https://space.bilibili.com/490711252
 * @title: UserThrealLocal
 * @projectName ksd-user-course-center
 * @description: TODO
 * @date 2021/9/2721:51
 */
public class UserThrealLocal {

    // 本地线程缓存: ThreadLocal 底层就是 Map
    private static ThreadLocal<KssUser> userThreadLocal = new ThreadLocal<KssUser>();

    public static void put(KssUser user) {
        userThreadLocal.set(user);
    }

    public static KssUser get() {
        return userThreadLocal.get();
    }

    public static void remove() {
        userThreadLocal.remove();
    }

}

```

在拦截器中存放

```java
package com.pug.config.interceptor;

import com.pug.config.anno.LoginCheck;
import com.pug.config.cache.EHCacheService;
import com.pug.config.threadlocal.UserThrealLocal;
import com.pug.constant.PugContants;
import com.pug.pojo.KssUser;
import com.pug.result.ResultEnum;
import com.pug.result.ex.KsdValidationException;
import com.pug.service.redis.PugRedisOperator;
import com.pug.utils.FastJsonUtil;
import com.pug.utils.fn.asserts.Vsserts;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/6$ 2:51$
 */
@Component
@Slf4j
public class PassportTokenInterceptor implements HandlerInterceptor, PugContants {

    @Autowired
    private PugRedisOperator redisOperator;
    @Autowired
    private EHCacheService ehCacheService;


    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (handler instanceof HandlerMethod) {
            HandlerMethod handlerMethod = (HandlerMethod) handler;
            // 让方法的优先级更高
            // 获取方法上面是否存在LoginCheck注解，如果存在并值是false.当然默认值也是false
            LoginCheck methodAnnotation = handlerMethod.getMethodAnnotation(LoginCheck.class);
            // methodAnnotation!=null 代表你加了注解,如果没加就不进入，就说明验证
            // !methodAnnotation.value() 加了如果是false，说明不需要验证了，就直接返回
            // 一句话：在开发中你要么不要加，要么加上去就使用默认值
            if (methodAnnotation!=null && !methodAnnotation.value()) {
                return true;
            }

            // 然后就是类的优先级
            Class<?> beanType = handlerMethod.getBeanType();
            LoginCheck annotation = beanType.getAnnotation(LoginCheck.class);
            if (annotation!=null && !annotation.value()) {
                return true;
            }
        }

        // 1: 获取前台接口调用请求头中的用户和token参数
        String authUserId = request.getHeader("AuthUserId");
        String authToken = request.getHeader("AuthToken");

        // 2: 如果token和userId是空的，就直接返回
        if (Vsserts.isNotEmpty(authUserId) && Vsserts.isNotEmpty(authToken)) {
            // 根据用户id查询缓存中的token
            String token = (String)ehCacheService.getCache(PUG_XQ_LOGIN_USER_TOKEN + authUserId);
            if(Vsserts.isEmpty(token)) {
                token = redisOperator.get(PUG_XQ_LOGIN_USER_TOKEN + authUserId);
            }
            // 如果是空，就说明退出了。
            if (Vsserts.isEmpty(token)) {
                //直接在前台响应地方跳转到登录去
                throw new KsdValidationException(ResultEnum.LOGIN_FAIL);
            }
            // 如果不是空，说明用户前台app或者小程序传递了token，
            // 把传递进来的token和缓存中的token进行比较看是否一致
            // google浏览器：说明它肯定退出一次然后又登录了 user:1 token 545454545
            // firefox浏览器：说明它肯定退出一次然后又登录了 user:1 token 878787878
            if (!token.equalsIgnoreCase(authToken)) {
                throw new KsdValidationException(ResultEnum.SAME_LOGIN);
            }
        } else {
            throw new KsdValidationException(ResultEnum.LOGIN_FAIL);
        }

        // 从缓存中获取用户信息
        KssUser kssUser = (KssUser)ehCacheService.getCache(PUG_XQ_LOGIN_USER_INFO + authUserId);
        if(Vsserts.isNull(kssUser)) {
            String userCacheJson = redisOperator.get(PUG_XQ_LOGIN_USER_INFO + authUserId);
            kssUser = FastJsonUtil.toBean(userCacheJson, KssUser.class);
        }

        //
        UserThrealLocal.put(kssUser);
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        UserThrealLocal.remove();
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        UserThrealLocal.remove();
    }
}

```





























