# Vue中ref和$refs的认识和使用

## $refs作用是什么呢？

就可以给子组件定义一个ref指定名字，然后通过this.$refs.名字就可以获取子组件的作用域。从而完成父组件调用子组件的一个行为的功能。

### 具体代码

父页面.vue

```vue
<template>
	<view>
		<view class="flex">Ref的讲解和分析</view>
		<pug-test ref="comment"></pug-test>
		<button @click="saveUser">保存</button>
				
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			saveUser(){
				this.$refs.comment.loadComment();
			}
		}
	}
</script>

<style>
	.flex{display: flex;justify-content: center;background:#ddd;
		padding:10px;
	}
	
	input[type='text']{border:1px solid #ccc;}
</style>

```

子组件.vue

```vue
<template>
	<view>
		我是一个子组件
	</view>
</template>

<script>
	export default {
		name:"pug-test",
		data() {
			return {
				
			};
		},
		methods:{
			loadComment(){
				console.log("===========okokokok===========")
			}
		}
	}
</script>

<style>

</style>

```





