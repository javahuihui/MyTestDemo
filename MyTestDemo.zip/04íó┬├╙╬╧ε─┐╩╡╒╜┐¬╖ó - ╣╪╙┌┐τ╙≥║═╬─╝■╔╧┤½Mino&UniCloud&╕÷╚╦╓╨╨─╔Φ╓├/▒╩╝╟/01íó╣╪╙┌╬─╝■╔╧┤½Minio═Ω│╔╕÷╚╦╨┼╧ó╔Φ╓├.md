# 关于文件上传Minio完成个人信息设置



前提封装了用户信息获取的常见操作。在App.vue中的methods中如下：

```js
<script>
	import cache from '@/config/cache'
	import utils from '@/config/utils'
	import provinceList from '@/json/area_province.js';
	import cityList from '@/json/area_city.js';
	import districtList from '@/json/area_district.js';

	export default {
		globalData: {
			provinceList: provinceList,
			cityList: cityList,
			districtList: districtList,
		},
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		},
		methods: {
			// set token
			setToken(token) {
				cache.set("token", token);
			},

			// 判断空
			isEmpty(str) {
				return utils.isEmpty(str);
			},
			
			// 获取token
			getToken() {
				var token = cache.get("token");
				if (utils.isEmpty(token)) {
					return "";
				}
				return token;
			},

			// 替换用户
			setUser(user) {
				user.token = user.token || this.getToken();
				cache.set("userinfo", user);
			},

			// 获取登录用户信息
			getUser() {
				var user = cache.get("userinfo");
				if (utils.isEmpty(user)) {
					return null;
				}
				return user;
			},
			
			
			// 是否登录
			isLogin(){
				var token = this.getToken()	;
				var userId = this.getUser().id	;
				return !this.isEmpty(token) && !this.isEmpty(userId);
			},
			

			// 移除用户信息
			removeUser() {
				cache.remove("userinfo");
				cache.remove("token");
				cache.remove("userid");
			},
		}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	@import "@/uni_modules/uview-ui/index.scss";
</style>

```





## 01、文件上传的主流方案

- 自己写使用Common-fileupload+SpringBoot — 单机版本
- 自己去搭建fastdfs 分布式的文件上传 — 没有图形化界面，全部都是命令
- 考虑使用线程的oss文件存储方案。阿里云，腾讯云等等——需要钱
- 自己搭建minio服务器进行文件存储—自己购买有个服务器进行部署和安装。
- unicloud云服务又10G云存储，并且已经做了CDN加速。



## 02、minio和oss

- 原理都一样，都是基于bucket来进行文件存储 – fastdfs / gdfs
- 一个是自己搭建，一个的掏钱购买
- 自己搭建文件都书自己，安全性，私密性肯定更好，如果你公司追求文件的版权肯定是自己搭建。



## 03、目标就是完成用户头像修改

1：你要准备好文件上传的功能

```java
package com.pug.web.upload;

import com.pug.config.minio.MinIOConfig;
import com.pug.config.minio.MinIoUploadService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/6 17:25
 */
@RestController
@Api(tags="文件上传")
@Slf4j
public class FileUploadController {

    @Autowired
    private MinIoUploadService minIoUploadService;
    @Autowired
    private MinIOConfig minIOConfig;

    @PostMapping("upload")
    @ApiOperation(value = "文件上传")
    public String upload(MultipartFile file) throws Exception {
        String fileName = file.getOriginalFilename();
        minIoUploadService.uploadFile(minIOConfig.getBucketName(), fileName, file.getInputStream());
        String imgUrl = minIOConfig.getFileHost()
                + "/"
                + minIOConfig.getBucketName()
                + "/"
                + fileName;

        return imgUrl;
    }
}

```

2：定义修改头像和背景图的接口

- 参数1：用户ID
- 参数2：avatar字段

第一种方案：前台传递把id传递过来

```java
@ApiOperation("修改用户头像接口")
@PostMapping("/user/modifty/avatar")
public String updateAvatar(@RequestBody KssUserSettingVo kssUserSettingVo) {
    Vsserts.isNullEx(kssUserSettingVo.getUserId(), "没有找到修改用户");
    KssUser kssUser = new KssUser();
    kssUser.setId(kssUserSettingVo.getUserId());
    kssUser.setAvatar(kssUserSettingVo.getAvatar());
    boolean b = userService.saveOrUpdate(kssUser);
    return b ? "success" : "fail";
}

@ApiOperation("修改用户背景")
@PostMapping("/user/modifty/bgimg")
public String updateBgImg(@RequestBody KssUserSettingVo kssUserSettingVo) {
    Vsserts.isNullEx(kssUserSettingVo.getUserId(), "没有找到修改用户");
    KssUser kssUser = new KssUser();
    kssUser.setId(kssUserSettingVo.getUserId());
    kssUser.setAvatar(kssUserSettingVo.getAvatar());
    boolean b = userService.saveOrUpdate(kssUser);
    return b ? "success" : "fail";
}
```

第二种方案：threadLocal服务端获取id

```java
```



3:打开me.vue文件进行头像修改

template部分

```html
<view class="base">
    <image @click.stop="changeMyFace()" class="profily_header" :src="userInfo.avatar" mode=""></image>
</view>
```

methods事件

```js
changeMyFace(){
    uni.navigateTo({
        animationType: "fade-in",
        url: "/pages/me/myFace"
    })
},
```

修改头像 myface.vue 

注意这个页面必须在: pages.json中进行注册。

```html
<style>
	.page {
		position: absolute;
		left: 0;
		right: 0;
		top: 0;
		bottom: 0;
		background-color: #000000;
	}

	.bg-wrapper {
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.bg-size {
		width: 750rpx;
		height: 750rpx;
	}

	.button-change-bg {
		background-color: #1e1e1e;
	}

	.button-change-bg-touched {
		background-color: #646262;
	}
</style>

<template>
	<view class="page">
		<view class="bg-wrapper" :style="{height: screenHeight + 'px'}">
			<image :src="faceUrl" class="bg-size" style="align-self: center;"></image>
			<view :class="{'button-change-bg':!changeTouched, 'button-change-bg-touched': changeTouched}"
				@touchstart="touchstartChange" @touchend="touchendChange" @click="changeFace()"
				style="width: 250rpx;height: 80rpx;border-radius: 50px;display: flex;flex-direction: column;justify-content: center;margin-top: 150rpx;align-self: center;">
				<text style="color: #FFFFFF;align-self: center;">更换头像</text>
			</view>
		</view>
	</view>
</template>

<script>
	var system = uni.getSystemInfoSync();
	var app = getApp();
	import userService from '@/service/user/UserService'
	import server from '@/config/server';
	export default {
		data() {
			return {
				faceUrl: app.getUser().avatar,
				changeTouched: false,
				screenHeight: system.safeArea.bottom,
			}
		},

		methods: {
			touchstartChange() {
				this.changeTouched = true;
			},

			touchendChange() {
				this.changeTouched = false;
			},
			
			uuid() {
			  var s = [];
			  var hexDigits = "0123456789abcdef";
			  for (var i = 0; i < 36; i++) {
				s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
			  }
			  s[14] = "4";
			  s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);
			  s[8] = s[13] = s[18] = s[23] = "-";
			  var uuid = s.join("");
			  return uuid;
			},

			// 更改头像
			changeFace() {
				var that = this;
				//前端代码
				uni.chooseImage({
					// 只能选择一张图片
					count: 1,
					// 如果选择成功就会进入到success中来进行处理了
					async success(res) {
						// res.tempFilePaths是一个临时文件
						if (res.tempFilePaths.length > 0) {
							// 取出你选中的文件
							let filePath = res.tempFilePaths[0]
							try {
								var userinfo = app.getUser();
								var index = userinfo.avatar.lastIndexOf("/");
								var filename = userinfo.avatar.substring(index + 1);
								var newfilename = filename || that.uuid();
								// 上传到minio中去 
								uni.uploadFile({
									url: `${server.baseURL}/api/user/modifty/avatar/${userinfo.id}`, //仅为示例，非真实的接口地址
									filePath: filePath,
									name: 'file',
									header:{
										"AuthToken":app.getToken(),
										"AuthUserId":app.getUserId()
									},
									formData: {
										"bucketname":"userapp"
									},
									success: (response) => {
										var res = JSON.parse(response.data);
										if(res.code == 200){
											var {avatar} = res.data; //var avatar = res.data.avatar;
											userinfo.avatar = avatar;
											app.setUser(userinfo);
											// 返回到个人首页
											uni.navigateBack({
												delta: 1,
												animationType: "fade-out"
											})
										}
									}
								});
							} catch (e) {
								console.log(e)
								uni.$u.toast("头像上传失败...")
							}
						}
					}
				});
			}
		}
	}
</script>

```

4：核心功能分析:

- uni.chooseImage 拉起手机的相册和拍照功能 —-负责选中你要替换的头像文件

- uni.uploadFile 文件上传的方法，注意这个细节，因为这个上传和http请求已经两回事，所以你url必须是文件上传的完整的地址

- 替换缓存和回退

  ```js
  // 头像取出
  var {avatar} = res.data; //var avatar = res.data.avatar;
  // 把本地内存的头像进行变更
  userinfo.avatar = avatar;
  // 替换本地缓存中之前的用户信息
  app.setUser(userinfo);
  // 返回到个人首页
  uni.navigateBack({
      delta: 1,
      animationType: "fade-out"
  })
  ```

- 回退以后会进入个人中心的首页，而用户信息同步是使用onShow()同步的

  onShow() , 你回退还是切换tabbar都会进入的生命周期，这个是不是就是一个绝佳的同步和刷新页面的一个位置。可以把每次修改内存中的值实时同步到页面视图中。

  ```
  ```

  





## 04、目标就是完成用户背景修改

同理







